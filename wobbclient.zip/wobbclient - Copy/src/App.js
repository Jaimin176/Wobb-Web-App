import './App.css';
import React, {useState} from 'react';
import { Navbar } from './Components/Navbar';
import notification from './notification.png'
import filter from './filter.png'
import brandimage from './brandimage.jpg'
import brandlogo from './brandlogo.jpg'

function App() {

  const [user, setUser] = useState("Wobber")

  return (
    <div className="App">

      <div className='navbar-wrapper'>
        <div className='header-one'>
          <div>Hii, {user}</div>

          <div className='notificationImg'><img src={notification} alt='Notification'/></div>
        </div>
        
        <Navbar />
      </div>

      <div className='content-container'>
        <div className='filters-list'>
          <div className='filter-icon'>
            <img src={filter} alt="Filter" />
          </div>

          <div className='filter-list'>
            <span className='active'>All(11)</span>
            <span>Applied(10)</span>
            <span>Hired(0)</span>
            <span>Closed(10)</span>
          </div>
        </div>

        <div className='cards-grid'>
          <div className='campaign-card'>
            <div className="campaign-image">
              <img src={brandimage} alt='Campaign' />
            </div>

            <div className='brand-meta'>
              <div className='brand-logo'>
                <img src={brandlogo} alt="Brand"/>
              </div>

              <span className='brand-name'>Wear the Era (1968)</span>
              <span className='campaignData'>Barter Worth</span>
              <span className='campaignAmount'>INR 1096</span>
              <span className='campaignLimit'>0/30 Hired</span>
            </div>
          </div>

          <div className='campaign-card'>
            <div className="campaign-image">
              <img src={brandimage} alt='Campaign' />
            </div>

            <div className='brand-meta'>
              <div className='brand-logo'>
                <img src={brandlogo} alt="Brand"/>
              </div>

              <span className='brand-name'>Wear the Era (1968)</span>
              <span className='campaignData'>Barter Worth</span>
              <span className='campaignAmount'>INR 1096</span>
              <span className='campaignLimit'>0/30 Hired</span>
            </div>
          </div>

          <div className='campaign-card'>
            <div className="campaign-image">
              <img src={brandimage} alt='Campaign' />
            </div>

            <div className='brand-meta'>
              <div className='brand-logo'>
                <img src={brandlogo} alt="Brand"/>
              </div>

              <span className='brand-name'>Wear the Era (1968)</span>
              <span className='campaignData'>Barter Worth</span>
              <span className='campaignAmount'>INR 1096</span>
              <span className='campaignLimit'>0/30 Hired</span>
            </div>
          </div>

          <div className='campaign-card'>
            <div className="campaign-image">
              <img src={brandimage} alt='Campaign' />
            </div>

            <div className='brand-meta'>
              <div className='brand-logo'>
                <img src={brandlogo} alt="Brand"/>
              </div>

              <span className='brand-name'>Wear the Era (1968)</span>
              <span className='campaignData'>Barter Worth</span>
              <span className='campaignAmount'>INR 1096</span>
              <span className='campaignLimit'>0/30 Hired</span>
            </div>
          </div>

          <div className='campaign-card'>
            <div className="campaign-image">
              <img src={brandimage} alt='Campaign' />
            </div>

            <div className='brand-meta'>
              <div className='brand-logo'>
                <img src={brandlogo} alt="Brand"/>
              </div>

              <span className='brand-name'>Wear the Era (1968)</span>
              <span className='campaignData'>Barter Worth</span>
              <span className='campaignAmount'>INR 1096</span>
              <span className='campaignLimit'>0/30 Hired</span>
            </div>
          </div>


          <div className='campaign-card'>
            <div className="campaign-image">
              <img src={brandimage} alt='Campaign' />
            </div>

            <div className='brand-meta'>
              <div className='brand-logo'>
                <img src={brandlogo} alt="Brand"/>
              </div>

              <span className='brand-name'>Wear the Era (1968)</span>
              <span className='campaignData'>Barter Worth</span>
              <span className='campaignAmount'>INR 1096</span>
              <span className='campaignLimit'>0/30 Hired</span>
            </div>
          </div>


          <div className='campaign-card'>
            <div className="campaign-image">
              <img src={brandimage} alt='Campaign' />
            </div>

            <div className='brand-meta'>
              <div className='brand-logo'>
                <img src={brandlogo} alt="Brand"/>
              </div>

              <span className='brand-name'>Wear the Era (1968)</span>
              <span className='campaignData'>Barter Worth</span>
              <span className='campaignAmount'>INR 1096</span>
              <span className='campaignLimit'>0/30 Hired</span>
            </div>
          </div>


          <div className='campaign-card'>
            <div className="campaign-image">
              <img src={brandimage} alt='Campaign' />
            </div>

            <div className='brand-meta'>
              <div className='brand-logo'>
                <img src={brandlogo} alt="Brand"/>
              </div>

              <span className='brand-name'>Wear the Era (1968)</span>
              <span className='campaignData'>Barter Worth</span>
              <span className='campaignAmount'>INR 1096</span>
              <span className='campaignLimit'>0/30 Hired</span>
            </div>
          </div>

          <div className='campaign-card'>
            <div className="campaign-image">
              <img src={brandimage} alt='Campaign' />
            </div>

            <div className='brand-meta'>
              <div className='brand-logo'>
                <img src={brandlogo} alt="Brand"/>
              </div>

              <span className='brand-name'>Wear the Era (1968)</span>
              <span className='campaignData'>Barter Worth</span>
              <span className='campaignAmount'>INR 1096</span>
              <span className='campaignLimit'>0/30 Hired</span>
            </div>
          </div>

          <div className='campaign-card'>
            <div className="campaign-image">
              <img src={brandimage} alt='Campaign' />
            </div>

            <div className='brand-meta'>
              <div className='brand-logo'>
                <img src={brandlogo} alt="Brand"/>
              </div>

              <span className='brand-name'>Wear the Era (1968)</span>
              <span className='campaignData'>Barter Worth</span>
              <span className='campaignAmount'>INR 1096</span>
              <span className='campaignLimit'>0/30 Hired</span>
            </div>
          </div>


          <div className='campaign-card'>
            <div className="campaign-image">
              <img src={brandimage} alt='Campaign' />
            </div>

            <div className='brand-meta'>
              <div className='brand-logo'>
                <img src={brandlogo} alt="Brand"/>
              </div>

              <span className='brand-name'>Wear the Era (1968)</span>
              <span className='campaignData'>Barter Worth</span>
              <span className='campaignAmount'>INR 1096</span>
              <span className='campaignLimit'>0/30 Hired</span>
            </div>
          </div>

          <div className='campaign-card'>
            <div className="campaign-image">
              <img src={brandimage} alt='Campaign' />
            </div>

            <div className='brand-meta'>
              <div className='brand-logo'>
                <img src={brandlogo} alt="Brand"/>
              </div>

              <span className='brand-name'>Wear the Era (1968)</span>
              <span className='campaignData'>Barter Worth</span>
              <span className='campaignAmount'>INR 1096</span>
              <span className='campaignLimit'>0/30 Hired</span>
            </div>
          </div>

          <div className='campaign-card'>
            <div className="campaign-image">
              <img src={brandimage} alt='Campaign' />
            </div>

            <div className='brand-meta'>
              <div className='brand-logo'>
                <img src={brandlogo} alt="Brand"/>
              </div>

              <span className='brand-name'>Wear the Era (1968)</span>
              <span className='campaignData'>Barter Worth</span>
              <span className='campaignAmount'>INR 1096</span>
              <span className='campaignLimit'>0/30 Hired</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
