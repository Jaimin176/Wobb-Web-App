import React from 'react'
import bullhorn from './bullhorn.png'
import messenger from './messenger.png'
import user from './user.png'

export const Navbar = () => {
  return (
    <div className='navbar-home'>
        <ul>
            <li className='active'><img src={bullhorn} alt="Campaigns"/> Campaigns</li>
            <li><img src={messenger} alt="messenger"/> Messages</li>
            <li><img src={user} alt="User"/>Profile</li>
        </ul>
    </div>
  )
}
